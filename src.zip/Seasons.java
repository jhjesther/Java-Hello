
public class Seasons {
	{
		int month = 10; 
		
		switch (month) {
		case 12:
		case 1:
		case 2:
		case 3:
			System.out.println("봄입니다");
			break;
		case4:case5:case6:	
			System.out.println("봄입니다");
			break;
		case 7:
		case 8:
			System.out.println("여름입니다");
			break;
		default:
		case9:
		case10:
		case11:
			System.out.println("가을입니다");
			break;
			
		default:
			System.out.println("잘못된 입력입니다.")
			
		}
		
		System.out.println("프로그램 종료");
			

	}
}

}
