
public class Quiz3 {
public static void main(String[] args) {



}
}
