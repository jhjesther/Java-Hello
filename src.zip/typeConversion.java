
public class typeConversion {
	int num1 = 50;
	long num2 = 3147483647;
	System.out.println(num1 + num2);
}
