
public class GradeExample {
	public static void main(String[] args) {
	int result = (5 < 4)? 50 : 40;
	
	System.out.println(result);
}
