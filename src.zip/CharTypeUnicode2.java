
public class CharTypeUnicode2 {
	public static void main(String[] args)
	
	int num1 = 4;
	int num2 = 3;
	double num3 = num2 / num1
	
	System.out.println(num3)
}
