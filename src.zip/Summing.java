
public class Summing {
	/* sum={(n+1)}*(n/2)}
			
			1+2+3+ ...10 = (1 + 10)*(10/2)
}
		
			n=2
	    1+2 = 3
		n=3
		1+2+3 = 6
		n=4
		1+2+3+4 = 10
		
		n=10
        1+2+3+4+5+6...+10 = 55 */
	
	
	public static void main
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		