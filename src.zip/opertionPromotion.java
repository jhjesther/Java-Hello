
public class opertionPromotion {
	public static void main(String[] ars) {
		
		char ch = 'A'; 
		System.out.println(ch);
		System.out.print((int)ch);
	}
}
