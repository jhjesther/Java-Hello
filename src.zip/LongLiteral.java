
public class LongLiteral {
	System.out.println(3147483647L + 3147483648L);

	/*
	byte seven = 0B11;
	int num 205= 0B11001101;
	
	int num = 100_000_000;
	int num = 12_34_56_78_90;

}
*/