////////짝수단만 출력하시오//////////////
/* public class EvenNumberDan {
for (i = 2; i<=9; i++)
	if(i%2==1)
		continue;
	for(j = 1;  j<=9, j++)
		if(i<j)
}		break; */
//////////홀수단만 출력하시오////////////

public class OddNumberDan{
	public static void main(String[] args)
	for (int i=1; i<=9; i++) 
		for (int j = 1; j<=9; j++) {
			int result= i*j;
			if(result % 2 == 1)
				System.out.println(i + "*" + j + "=" + result);
	}

}


			
