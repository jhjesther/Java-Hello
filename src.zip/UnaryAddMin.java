
public class UnaryAddMin {
	public static void main(String][ args]) {
		short num2 = 7;
		short num3 = (short)(+num2);
		short num 4 = (short)(-num2);
		System.out.println
		
	}
}
