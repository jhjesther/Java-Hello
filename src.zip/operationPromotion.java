
public class operationPromotion {
		public static void main(String[]args) {
			
			long num1 = 2100000000;
			long num2 = 2100000000;
			
			long result = num1 + num2;
			
			System.out.println(result);
		}
}
