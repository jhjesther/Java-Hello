
public class BreakContinue {
//1부터 1000까지 수 중 11의 배수이자 7의 배수인 첫번째 수
	for (int i=1;  i<=1000; i ++ ) {
	if((i%7 ==0)&&((i % 11 == 0));
	System.out.println(i)
	break;
	

}
