
public class DoWhile {
	
	for(int i=0; i<4; i++)  {
		System.out.println("무한루프")
	}
	for int (i=1; i<10; i++) {
		sum = sum + 1;
	}
	System.out.println(sum);
	
	for int (i=1; i<100; i++) {
		sum = sum + 1;
	}
	System.out.println(sum);
	/////////////////////////////////////////////////
	for int (j=1; j<100; j++) {
		if(j%2 == 0) {
		sum = sum + j;
	}
	System.out.println(sum);
	////////////////////////////////////////////////
	for int (j=1; j<100; j++) {
		if(j%2 == 1) {
		sum = sum + j;
	}
	System.out.println(sum);
	////////////////////////////////////////////////
	
	3단
	3 * 1 = 3
	3 * 2 = 6
	
			for (int i = 1; i < 10; i += 3) {

				for (int j = 1; j < 10; j++) {

					for (int k = i; k < i + 3; k++)

						System.out.printf(k + "*" + j + "=" + k * j + "\t");

						System.out.println();

				}

				System.out.println();

				/////////////////////////////////////////////////
				
				
				int dana = 3;
				for (int i = 1; i<=9; i++){
					System.out.println(dan + "*" + i + "=" + (dan*i));
				}
				////////////////////////////////////////////////////
				int dana = 7;
				for (int i = 1; i<=9; i++){
					System.out.println(dan + "*" + i + "=" + (dan*i));
				}
				
				
				
				
				
				
				
			}
	
	
	
	
	

		}

	}
}
