
public class ExplicitConversion {
	double pi = 3.1415
	int wholeNumber = (int)pi;
	
	long num1 = 3000000007L;
	int num2 = (int)num1;
	
	short num1 = 1;
	short num2 = 2;
	short num3 = (short)(num1 + num2)
			
	
	
	
	
}
