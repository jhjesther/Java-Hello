
public class Hello {
	public static void main(String[] args) {
		int num = 1;
		
		while(num<=100) {
			System.out.println("Hello world!" + num);
			num++;
		}
		
		System.out.println(num);
		
	}
}
